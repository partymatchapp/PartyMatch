"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";

import { useUser } from "@/context/UserContext";

import { getEvent } from "@/lib/events";
import {
  joinEvent,
  getUserProfile
} from "@/lib/users";

import {
  getUnreadNotificationsCount
} from "@/lib/notifications";

import Discovery from "@/components/Discovery";
import EventLobby from "@/components/EventLobby";
import Notifications from "@/components/Notifications";
import Matches from "@/components/Matches";
import Chats from "@/components/Chats";



type Vista =
  | "discovery"
  | "participantes"
  | "notificaciones"
  | "matches"
  | "chats";




export default function EventoPage(){


  const params = useParams();

  const router = useRouter();


  const id = params.id as string;


  const {
    user,
    loading
  } = useUser();




  const [evento,setEvento] =
    useState<any>(null);


  const [cargando,setCargando] =
    useState(true);


  const [error,setError] =
    useState("");



  const [vista,setVista] =
    useState<Vista>("discovery");



  const [notificaciones,setNotificaciones] =
    useState(0);




  async function cargarNotificaciones(){


    if(!user){

      return;

    }



    try{


      const cantidad =
        await getUnreadNotificationsCount(
          user.uid
        );


      setNotificaciones(cantidad);


    }catch(error){


      console.error(
        error
      );


    }


  }





  useEffect(()=>{


    async function iniciar(){


      try{


        if(!id){

          throw new Error(
            "Evento inválido"
          );

        }




        const datos =
          await getEvent(id);




        if(!datos){


          throw new Error(
            "Evento no encontrado"
          );


        }



        setEvento(datos);





        if(loading){

          return;

        }




        if(!user){


          router.push(
            `/login?evento=${id}`
          );


          return;

        }





        const perfil =
          await getUserProfile(
            user.uid
          );





        if(
          !perfil ||
          !perfil.perfilCompleto
        ){


          router.push(
            `/crear-perfil?evento=${id}`
          );


          return;


        }





        await joinEvent(

          user.uid,

          id

        );





        await cargarNotificaciones();




      }catch(error:any){



        console.error(
          error
        );


        setError(
          error.message
        );


      }finally{


        setCargando(false);


      }


    }




    iniciar();



  },[
    id,
    user,
    loading
  ]);





  if(
    cargando ||
    loading
  ){


    return(

      <div className="
        min-h-screen
        bg-black
        text-white
        flex
        items-center
        justify-center
      ">

        Cargando evento...

      </div>

    );


  }





  if(error){


    return(

      <div className="
        min-h-screen
        bg-black
        text-white
        flex
        items-center
        justify-center
      ">

        {error}

      </div>

    );


  }





  if(!evento){

    return null;

  }





  return(

    <main className="
      min-h-screen
      bg-black
      text-white
      pb-24
    ">


      <header className="
        p-5
        text-center
      ">


        <h1 className="
          text-3xl
          font-bold
        ">

          {evento.nombre} 🎉

        </h1>


      </header>





      <section className="
        max-w-md
        mx-auto
        px-4
      ">



        {
          vista === "discovery" && (

            <Discovery
              eventoId={id}
            />

          )
        }



        {
          vista === "participantes" && (

            <EventLobby
              eventoId={id}
            />

          )
        }



        {
          vista === "notificaciones" && (

            <Notifications/>

          )
        }



        {
          vista === "matches" && (

            <Matches/>

          )
        }



        {
          vista === "chats" && (

            <Chats/>

          )
        }



      </section>
            <nav className="
        fixed
        bottom-0
        left-0
        right-0
        bg-slate-900
        border-t
        border-gray-700
        p-3
        z-40
      ">


        <div className="
          max-w-md
          mx-auto
          flex
          justify-around
          items-center
        ">



          <button

            onClick={()=>setVista("discovery")}

            className={`
              flex
              flex-col
              items-center
              text-sm
              ${
                vista==="discovery"
                ?
                "text-blue-400"
                :
                "text-white"
              }
            `}

          >

            ❤️

            <span>
              Descubrir
            </span>

          </button>





          <button

            onClick={()=>setVista("participantes")}

            className={`
              flex
              flex-col
              items-center
              text-sm
              ${
                vista==="participantes"
                ?
                "text-blue-400"
                :
                "text-white"
              }
            `}

          >

            👥

            <span>
              Personas
            </span>

          </button>





          <button

            onClick={()=>setVista("notificaciones")}

            className="
              relative
              flex
              flex-col
              items-center
              text-sm
              text-white
            "

          >

            🔔

            {
              notificaciones > 0 && (

                <span className="
                  absolute
                  -top-2
                  bg-red-500
                  text-white
                  rounded-full
                  text-xs
                  px-2
                ">

                  {notificaciones}

                </span>

              )
            }


            <span>
              Avisos
            </span>


          </button>





          <button

            onClick={()=>setVista("matches")}

            className={`
              flex
              flex-col
              items-center
              text-sm
              ${
                vista==="matches"
                ?
                "text-pink-400"
                :
                "text-white"
              }
            `}

          >

            🎉

            <span>
              Match
            </span>

          </button>






          <button

            onClick={()=>setVista("chats")}

            className={`
              flex
              flex-col
              items-center
              text-sm
              ${
                vista==="chats"
                ?
                "text-green-400"
                :
                "text-white"
              }
            `}

          >

            💬

            <span>
              Chat
            </span>

          </button>




        </div>


      </nav>



    </main>

  );


}